<template>
  <div class="container">
   <div class="row">
    <h1>Search Page</h1>
	<AppSearchInput />
   </div>
  </div>
</template>